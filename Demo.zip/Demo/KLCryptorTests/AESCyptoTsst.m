//
//  AESCyptoTsst.m
//  KLCryptorTests
//
//  Created by kevin on 2020/7/10.
//  Copyright © 2020 kevin. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "KLAESCryptor.h"

@interface AESCyptoTsst : XCTestCase

@end

@implementation AESCyptoTsst

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

- (void)testGenerateAesKey{
    NSString *keyStr = [KLAESCryptor generateAesKeyWithLength:16];
    NSLog(@"-------key=%@", keyStr);
}

- (void)testCryString{
    NSString *keyStr = [KLAESCryptor generateAesKeyWithLength:16];
    NSLog(@"-------key=%@", keyStr);
    
    NSString *srcStr = @"aewerqwerqwerfsadfasdfasdf";
    
    NSString *desStr = [KLAESCryptor encryptString:srcStr password:keyStr error:nil];
    
    NSString *newSrcStr = [KLAESCryptor decryptString:desStr password:keyStr error:nil];
    
    if (![srcStr isEqualToString:newSrcStr]){
        NSLog(@"error %@, %@", srcStr, desStr);
        return;
    }
    NSLog(@"succes key= %@, srcStr= %@, desStr= %@", keyStr, srcStr, desStr);
}

- (void)testCryFile{
    NSString *keyStr = [KLAESCryptor generateAesKeyWithLength:16];
    NSLog(@"key=%@", keyStr);
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *srcFilePath  = [NSString stringWithFormat:@"%@/%@", paths[0], @"testfile.md"];
    NSString *desFilePath  = [NSString stringWithFormat:@"%@/%@", paths[0], @"testfile_c.crypto"];
    
    [KLAESCryptor encryptFilePath:srcFilePath desFilePath:desFilePath password:keyStr syncFlag:YES completion:^(NSError * _Nonnull error) {
        if (error){
            return;
        }
        NSLog(@"encryfile success =%@", desFilePath);
    }];
    
    NSString *mewsrcFilePath  = [NSString stringWithFormat:@"%@/%@", paths[0], @"testfilexxx.md"];
    
    [KLAESCryptor decryptFilePath:desFilePath desFilePath:mewsrcFilePath password:keyStr syncFlag:YES completion:^(NSError * _Nonnull error) {
        if (error){
            return;
        }
        NSLog(@"decryfile success =%@", desFilePath);
    }];
}




@end
