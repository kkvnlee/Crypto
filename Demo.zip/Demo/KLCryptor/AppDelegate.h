//
//  AppDelegate.h
//  ComCryptor
//
//  Created by kevin on 2020/7/8.
//  Copyright © 2020 kevin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

