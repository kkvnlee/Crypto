//
//  ViewController.m
//  ComCryptor
//
//  Created by kevin on 2020/7/8.
//  Copyright © 2020 kevin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
